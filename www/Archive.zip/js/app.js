var starter;
starter = angular.module('starter', ['ionic','ngCordova','chart.js'])

    .run(function ($ionicPlatform, $rootScope) {
        $ionicPlatform.ready(function () {
            if (window.cordova && window.cordova.plugins.Keyboard) {
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            }
            if (window.StatusBar) {
                StatusBar.styleDefault();
            }
        });
    })
    .controller('AppCtrl', function ($scope, $http,$document, $ionicSideMenuDelegate, $ionicPopup,$ionicPlatform, $cordovaGeolocation) {

        $scope.cb = {"checked": false};
        $scope.mesStations = [];
        $scope.pageTitle = "Prendre un Vélo";
        $scope.cacherBtnRight = false;
        $scope.cacherBtnLeft = true;
        $scope.stations = [];
        $scope.stationFavoris;
        $scope.labels = ["Velos Dispo", "Places Dispo"];
        $scope.colors = ["#9e9e9e","#ef4e3a"];
        var open = true;
        var map;
        var VELO_DISPO = "VELO_DISPO";
        var BORNES_DISPO = "BORNES_DISPO";
        var action = VELO_DISPO;
        var apiKey = '&apiKey=7a250017cf6524d013a3f3aeab071dada46ebe86';
        var timer = undefined;
        //Méthode bornes dispo
        $scope.getBorneDispo = function () {
            console.log("=====> Methode : getBorneDispo()");
            console.log($scope.cb.checked);
            //map.closePopup();
            action = BORNES_DISPO;
            $scope.cacherBtnRight = true;
            $scope.cacherBtnLeft = false;
            $scope.pageTitle = "Déposer un Vélo";
            Stations.updateMarkerStations();
        };

        //Méthode vélos dispo
        $scope.getVeloDispo = function () {
            console.log("=====> Methode : getVeloDispo()");
            console.log($scope.cb.checked);
            //map.closePopup();
            action = VELO_DISPO;
            $scope.cacherBtnRight = false;
            $scope.cacherBtnLeft = true;
            $scope.pageTitle = "Prendre un Vélo";
            Stations.updateMarkerStations();
        };

        $scope.onCheckedToggle = function () {
            Stations.updateMarkerStations();
        };

        $scope.addFavoris = function () {
            Favoris.add();
        };

        $scope.toggleLeft = function () {
        };

        $scope.centerToPosition = function(){
            map.setView([User.position.lat, User.position.lng], 15);
        };

        $scope.toggleMainPanel = function(){
            var heightSup = 296;
            var heightScreen = window.screen.height;
            var dist =  heightScreen - heightSup;
            var i = 1;
            var mapCanvas = document.getElementById("map");
            var cardStationProche = document.getElementById("cardStationProche");
            var footer = document.getElementById("footer");
            
            if(open){
                mapCanvas.style.height = (232 + dist)+"px";
                footer.style.marginTop = (237 + dist)+"px";
                cardStationProche.style.marginTop = (232 + dist)+"px";
                var latlng = map.getCenter();
                map.invalidateSize(true);
                //map.setView(latlng);
                open = false;
            }else{
                map.closePopup();
                mapCanvas.style.height = 232+"px";
                footer.style.marginTop = 237+"px";
                cardStationProche.style.marginTop = 232+"px";
                var latlng = map.getCenter();
                map.invalidateSize(true);
                //map.setView(latlng);
                open = true;
            }
        };

        $scope.showStation = function(station){
            $scope.toggleMainPanel();
            map.setView([station.position.lat, station.position.lng], 15);
            station.marker.openPopup();
        };

        $scope.showPanelGraph = function(station){
            console.log(station.name);
        };
        /**
         * Module de gestion des Favoris
         */
        var Favoris = {
            add: function () {

                var station = Marker.currentOpenPopup.station;
                station.marker.closePopup();
                station.favoris = true;
                var stationFavoris = {name: station.name, station: station, chart: ''};
                $scope.$apply($scope.mesStations.push(stationFavoris));


                Utils.log("Add Station to favoris");


                var dataFavorisChart = [
                    {
                        value: station.velosDispo,
                        color: "#ef4e3a",
                        highlight: "#ef4e3a",
                        label: "Vélos"
                    },
                    {
                        value: station.bornesDispo,
                        color: "#9e9e9e",
                        highlight: "#9e9e9e",
                        label: "Bornes"
                    }
                ];
                var ctx = document.getElementById('favoris-' + station.name).getContext("2d");
                stationFavoris.chart = new Chart(ctx).Doughnut(dataFavorisChart, {animateRotate: false});

                console.log(station);


                $ionicSideMenuDelegate.toggleLeft();
            }
        };

        /**
         * Station Modele
         */
        var Station = function (a) {
            var station = a, marker = {}, point = {}, nameStation = '';

            (function () {
                var index = station.name.indexOf('-');
                nameStation = station.name.substr(index + 1, station.name.length - 1);
            })();

            return {
                number: station.number,
                name: nameStation,
                velosDispo: station.available_bikes,
                bornesDispo: station.available_bike_stands,
                data:[station.available_bike_stands,station.available_bikes],
                statut: station.status,
                banking: station.banking,
                position: {
                    lat: station.position.lat,
                    lng: station.position.lng
                },
                marker: marker,
                point: point,
                distance: function () {
                    var result;
                    if (User.position.lat != 0 && User.position.lng != 0) {
                        result = this.point.distanceTo(User.point);
                        result = Math.round(result);
                        result = result + ' m';
                    } else {
                        result = "Indispo";
                    }
                    return result;
                },
                distanceInt: function () {
                    var result;
                    if (User.position.lat != 0 && User.position.lng != 0) {
                        result = this.point.distanceTo(User.point);
                        result = Math.round(result);
                    } else {
                        result = "Indispo";
                    }
                    return result;
                },
                equal: function (o) {
                    var diff = false;
                    if (this.velosDispo == o.available_bikes &&
                        this.bornesDispo == o.available_bike_stands &&
                        this.statut == o.status) {
                        diff = true;
                    }
                    return diff;
                },
                update: function (o) {
                    this.velosDispo = o.available_bikes;
                    this.bornesDispo = o.available_bike_stands;
                    this.statut = o.status;
                },
                favoris: false
            };
        };

        /**
         * Module de gestion des stations
         */
        var Stations = (function () {
            var stations = $scope.stations;
            return {
                init: function (data) {
                    for (var i = 0; i < data.length; i++) {
                        var station = new Station(data[i]);
                        station.marker = Marker.createStationMarker(station);
                        station.point = Marker.createStaionPoint(station);
                        this.addStation(station);
                    }
                },
                addStation: function (station) {
                    var key = station.number;
                    stations[key] = station;
                },
                station: function (key) {
                    return stations[key];
                },
                updatePopupStations: function () {
                    for (key in stations) {
                        var marker = stations[key].marker;
                        marker.bindPopup(Marker.infoStationContent(stations[key]));
                    }
                },
                updateMarkerStations: function () {
                    for (key in stations) {
                        Marker.updateStationMarker(stations[key]);
                    }
                },
                refreshStationsData: function () {
                    console.log("=====> Update Data Stations");
                    $http.get('https://api.jcdecaux.com/vls/v1/stations?contract=nantes' + apiKey)
                        .success(function (data) {
                            var i = -1;
                            Utils.sort(data);
                            for (key in stations) {
                                i++;
                                var station = stations[key];
                                var updateStation = data[i];
                                if (!station.equal(updateStation)) {
                                    Utils.log("Update Station : " + station.name);
                                    console.log(station);
                                    console.log(updateStation);
                                    station.update(updateStation);
                                    Marker.updateStationMarker(station);

                                    var popupMarker = station.marker.getPopup();
                                    popupMarker.setContent(Marker.infoStationContent(station));
                                    popupMarker.update();
                                    //marker.setPopupContent();

                                    //Mise à jour du graphique
                                    if (station.name == Marker.currentOpenPopup) {
                                        // $scope.myChart.segments[0].value = station.available_bikes;
                                        // $scope.myChart.segments[1].value = station.available_bike_stands;
                                        // $scope.myChart.update();
                                        var dataChart = [
                                            {
                                                value: station.available_bikes,
                                                color: "#ef4e3a",
                                                highlight: "#ef4e3a",
                                                label: "Vélos"
                                            },
                                            {
                                                value: station.available_bike_stands,
                                                color: "#9e9e9e",
                                                highlight: "#9e9e9e",
                                                label: "Bornes"
                                            }
                                        ];

                                        var ctx = document.getElementById(station.name).getContext("2d");
                                        $scope.myChart = undefined;
                                        $scope.myChart = new Chart(ctx).Doughnut(dataChart, {animateRotate: false});

                                    }

                                }
                            }
                        });
                }
            };
        })();

        /**
         * User Modele
         */
        var User = {
            position: {
                lat: 0,
                lng: 0
            },
            marker: {},
            point: {}
        };

        /**
         * Module de gestion des markers
         */
        var Marker = (function () {
            var marker;
            var currentOpenPopup = {
                name: {},
                chart: {},
                station: {}
            };
            return {
                currentOpenPopup: currentOpenPopup,
                createMarker: function (lat, lng, option) {
                    return L.marker([lat, lng], option).addTo(map);
                },
                createUserPositionMarker: function () {
                    var option = {
                        icon: L.divIcon({
                            //Style CSS of markeru
                            className: 'currentPos',
                            //HTML value inner marker
                            html: '',
                            // Set a markers width and height.
                            iconSize: [22, 22]
                        })
                    };
                    return this.createMarker(User.position.lat, User.position.lng, option);

                },
                createStationMarker: function (station) {
                    var content = (station.status == "CLOSED") ? 'HS' : (action == VELO_DISPO) ? station.velosDispo : station.bornesDispo;
                    var classMarker = ($scope.cb.checked == true && station.banking == false && action == VELO_DISPO) ? 'count-icon-hidden' : ((content != 'HS' && content > 0) ? 'count-icon' : 'count-icon-close');
                    var option = {
                        icon: L.divIcon({
                            className: classMarker,
                            html: content,
                            iconSize: [40, 40]
                        })
                    };
                    marker = this.createMarker(station.position.lat, station.position.lng, option);
                    marker.bindPopup(this.infoStationContent(station));

                    marker.addEventListener("popupopen", function () {
                        if (open) {
                            $scope.toggleMainPanel();
                        }
                        currentOpenPopup.name = station.name;
                        $scope.stationFavoris = station.favoris;
                        var data = [
                            {
                                value: station.velosDispo,
                                color: "#ef4e3a",
                                highlight: "#ef4e3a",
                                label: "Vélos"
                            },
                            {
                                value: station.bornesDispo,
                                color: "#9e9e9e",
                                highlight: "#9e9e9e",
                                label: "Bornes"
                            }
                        ];

                        var ctx = document.getElementById(station.name).getContext("2d");
                        currentOpenPopup.chart = new Chart(ctx).Doughnut(data);

                        var btnFavoris = document.getElementById('favoris');
                        if (station.favoris) {
                            btnFavoris.style.display = "none";
                        } else {
                           btnFavoris.addEventListener('click', $scope.addFavoris, false);
                            btnFavoris.style.display = "initial";
                        }


                        currentOpenPopup.station = station;
                    }, station);
                    return marker;
                },
                createStaionPoint: function (station) {
                    return L.latLng(station.position.lat,
                        station.position.lng);
                },
                createPositionPoint: function () {
                    return L.latLng(User.position.lat,
                        User.position.lng);
                },
                infoStationContent: function (station) {
                    var bankingExist = (station.banking == true) ? ' <i class="icon ion-card"></i>' : '';
                    var info = '<div id="popup"><h3>' + station.name + bankingExist + '</h3>';
                    info += '<div class="row">';
                    info += '<div class="col">';
                    info += '<canvas id="' + station.name + '" width="90" height="90"></canvas>';
                    //info += '<canvas id="doughnut" class="chart chart-doughnut" data="'+station.data+'" labels="'+$scope.labels+'" colours="'+$scope.colors+'"></canvas>'
                    info += '</div>';
                    info += '<div class="col">';
                    info += '<p style="color:#ef4e3a;font-size: 23px;">' + station.velosDispo + ' Vélos</p>';
                    info += '<p style="color:#838383;font-size: 23px;">' + station.bornesDispo + ' Places</p>';


                    info += '<p style="color:#484848;font-size: 15px;"><i class="icon ion-location"></i> ' + station.distance() + '</p>';

                    info += '</div>';
                    info += '</div>';
                    info += '<div class="row">';
                    info += '<div class="col" ng-hide="stationFavoris"><button class="button button-block button-small button-outline  button-assertive ion-ios7-heart" id="favoris"> Favoris</button></div>';
                    info += '<div class="col"><a href="http://maps.apple.com/?q=cupertino"><button class="button button-block button-small button-outline  button-dark ion-ios7-flag" ng-click=""> Itinéraire</button></a></div>';
                    info += '</div>';
                    info += '</div>';

                    return info;
                },
                updateStationMarker: function (station) {
                    var marker = station.marker;
                    var content = (station.status == "CLOSED") ? 'HS' : (action == VELO_DISPO) ? station.velosDispo : station.bornesDispo;
                    var classMarker = ($scope.cb.checked == true && station.banking == false && action == VELO_DISPO) ? 'count-icon-hidden' : ((content != 'HS' && content > 0) ? 'count-icon' : 'count-icon-close');
                    marker.setIcon(L.divIcon({
                            //Style CSS of marker
                            className: classMarker,
                            //HTML value inner marker
                            html: content,
                            // Set a markers width and height.
                            iconSize: [40, 40]
                        })
                    );
                }
            };
        })();

        /**
         * Function automatiquement appeler
         * Si la géolocalisation du device est réussi
         *
         * @param position
         */
        var onSuccess = function (position) {
            Utils.log('Position Success');
            User.position.lat = position.coords.latitude;
            User.position.lng = position.coords.longitude;
            User.marker = Marker.createUserPositionMarker();
            User.point = Marker.createPositionPoint();
            console.log(User.position.lat + '|' + User.position.lng);
            map.setView([User.position.lat, User.position.lng], 15);
            Stations.updatePopupStations();
            timer = app.startRefresh();
        };

        /**
         * Function appeler automatiquement
         * Si la géolocalisation du device est réussi
         *
         * @param exception
         */
        var onError = function (e) {
            $ionicPopup.alert({
                title: 'Error Location',
                template: e.message
            });
            Utils.log('Position Error');
            map.setView([47.218371, -1.553621], 15);
            //initLeftPanel();
            timer = app.startRefresh();
        };

        /**
         * Module de gestion des etats de l'application
         * Démarrage de l'application,
         * Pause (passage de l'application en background),
         * Reprise (Retour sur l'application)
         * Masquer l'application en cours de chargement
         * Affichage de l'application chargé
         *
         * @type {{startRefresh: Function, stopRefresh: Function, resumeRefresh: Function}}
         */
        var app = {
            startRefresh: function () {
                Utils.log("Start Refresh methode");
                return setInterval(Stations.refreshStationsData, 30000);
            },
            stopRefresh : function(){
                clearInterval(timer);
            },
            resumeRefresh : function(){
                $ionicPopup.alert({
                    title: 'Rebonjour',
                    template: 'Test Reprise'
                });
                timer = this.startRefresh();
            }
        };
        $ionicPlatform.on('pause',app.stopRefresh);
        $ionicPlatform.on('resume',app.resumeRefresh);


        //Initialisation de l'application
        var startApp = function () {
            Utils.log('Starting App');
            L.mapbox.accessToken = 'pk.eyJ1Ijoia2VteTk3MSIsImEiOiJNS3UwWVgwIn0.XMwOcHaSlli4iZ8dBbfbOA';
            map = L.mapbox.map('map', 'kemy971.k3ef99fc', {zoomControl: false, attributionControl : false}).setView([47.218371, -1.553621], 15);
            map.on('click',function(){
                if (open) {
                    $scope.toggleMainPanel();
                };
            });
            $http.get('https://api.jcdecaux.com/vls/v1/stations?contract=nantes' + apiKey)
                .success(function (data) {
                    Utils.sort(data);
                    Stations.init(data);
                    //document.getElementById('starter').style.visibility = "visible";
                    Utils.hidden("loader-content");
                    Utils.show("starter-content");
                    Utils.log('Get Position');
                    //navigator.geolocation.getCurrentPosition(onSuccess, onError, {
                        $cordovaGeolocation.getCurrentPosition({
                        timeout: 10000,
                        enableHighAccuracy: true
                    }).then(onSuccess, onError);
                });
        };

        //Auto-start app
        (function () {
            $http.get("../config.json")
                .success(function (data) {
                    $scope.cb.checked = data.stationCB;
                    //$scope.mesStations = data.mesStations;
                    startApp();
                })
                .error(function (e) {
                    startApp();
                });
        })();
    });

angular.element(document).ready(function () {
    var domElement = document.getElementById('starter');
    angular.bootstrap(domElement, ["starter"]);
}); 